# Stochastic Gradient Descent
    #Steps
    #1. select sample
    #2. compute theta
    #3. compute cost
    #4. update theta
    #5. loop until get min J
from sklearn.metrics import r2_score

from ex1_helper import gradient_descent, comp_hx
import numpy as np
# from lab4.ex4_helper import comp_hx, comp_J, comp_theta
from sklearn.model_selection import train_test_split
import pandas as pd


#Common Param
seed = 94


#data processing`1
df = pd.read_csv("../lab3/simulated_data_multiple_linear_regression_for_ML.csv")
print(df.info())

#remove unnecessary columns
df = df.iloc[:,1:]
print(df.columns)

features = ['BMI', 'BP', 'blood_sugar', 'Gender', 'disease_score']
target =  'disease_score_fluct'

# def comp_theta(X,y): #X,y=  X_train, y_train
#     X = np.c_[np.ones((X.shape[0], 1)), X] # intercept
#     Xt_X = np.dot(X.T,X)
#     inv_Xt_X = np.linalg.inv(Xt_X)
#
#     Xt_y = np.dot(X.T,y)
#     theta = np.dot(inv_Xt_X, Xt_y)
#     return theta

#model fit
#select random index
np.random.seed(seed)
X = df[features]
y = df[target]

X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.33, random_state=42 )
print(X_train.shape, X_test.shape, y_train.shape, y_test.shape)


rand_ind = np.random.randint(0,40)
print(rand_ind)

X_train_ = np.c_[np.ones((X_train.shape[0], 1)), X_train]  # intercept
X_test_ = np.c_[np.ones((X_test.shape[0], 1)), X_test]  # intercept


#select random sample for stochasticity
X_train_st = X_train_[ rand_ind, :]
y_train_st = y_train[rand_ind]

print(X_train_st)

#compute cost

J_history, theta_history  = gradient_descent(X_train_st,y_train_st,50,alpha=0.000001)
print(J_history)
print(theta_history[-1,:])

#get optimal theta value
op_theta = theta_history[-1,:]

#compute y_pred
y_pred_test = comp_hx(X_test_,op_theta )

#compute r2 score value
r2 = r2_score(y_pred_test,y_test)
print('R2 score: ',r2)

#plot
import seaborn as sns
import matplotlib.pyplot as plt

sns.regplot(x=y_test, y=y_pred_test, label="Testing Data")

plt.xlabel('Actual value (y_test)')
plt.ylabel('Predicted value (y_pred_test)')
plt.title(f'SGD : Actual vs. Predicted; Data')
plt.legend(loc="upper left")
plt.show()
