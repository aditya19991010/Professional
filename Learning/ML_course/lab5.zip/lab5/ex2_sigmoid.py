# Implement sigmoid function in python and visualize it

# equation
#1.  hx = (y - hx)xi
#2. y_pred = threshold 0-1
#3. r2 score

import os
import pandas as pd
import numpy as np

#Generate random mat
X1 = np.random.randint(0,10, 30)
X2 = np.random.randint(90,100, 30)
X3 = np.random.randint(90,800, 30)
y = np.random.randint(1,100, 30)

X = [X1, X2, X3]
print(X)



