import numpy as np
import pandas as pd
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split

# Common Param
seed = 89

# Data processing
df = pd.read_csv("../lab3/simulated_data_multiple_linear_regression_for_ML.csv")
print(df.info())

# Remove unnecessary columns
df = df.iloc[:, 1:]
print(df.columns)

features = ['BMI', 'BP', 'blood_sugar', 'Gender', 'disease_score']
target = 'disease_score_fluct'

# Split the data
X = df[features]
y = df[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=seed)
print(X_train.shape, X_test.shape, y_train.shape, y_test.shape)

# Add intercept term to X
X_train = np.c_[np.ones((X_train.shape[0], 1)), X_train]
X_test = np.c_[np.ones((X_test.shape[0], 1)), X_test]

# Initialize theta
np.random.seed(seed)
theta = np.random.randn(X_train.shape[1])  # Random initialization

# Hyperparameters
learning_rate = 0.0000001  # Step size
n_epochs = 100  # Number of epochs

# Stochastic Gradient Descent
    # Shuffle the training data
    # Iterate over each training example
    # Compute prediction
    # Compute error
    # Update theta
    # Print cost every 10 epochs
    # Compute predictions for the entire training set
    # Compute cost (MSE)


for epoch in range(n_epochs):
    # Shuffle the training data
    shuffled_indices = np.random.permutation(X_train.shape[0])
    X_train_shuffled = X_train[shuffled_indices]
    y_train_shuffled = y_train.iloc[shuffled_indices]

    # Iterate over each training example
    for i in range(X_train_shuffled.shape[0]):
        xi = X_train_shuffled[i]  # Single training example
        yi = y_train_shuffled.iloc[i]  # Corresponding target

        # Compute prediction
        hx = np.dot(xi, theta)

        # Compute error
        error = hx - yi

        # Update theta
        gradient = error * xi
        theta -= learning_rate * gradient

    # Print cost every 10 epochs
    if epoch%2==0:
        # Compute predictions for the entire training set
        y_pred_train = np.dot(X_train, theta)
        # Compute cost (MSE)
        mse_1 = np.mean((y_pred_train - y_train) ** 2)
        print(f"Epoch {epoch}, Cost (MSE): {mse_1}")

# Final theta
print("Final theta:", theta)

# Predict on test data
y_pred_test = np.dot(X_test, theta)
print("Test predictions:", y_pred_test)

print(r2_score(y_pred_test,y_test))
# Compute cost (MSE) for test data
mse_test = np.mean((y_pred_test - y_test) ** 2)
print("Test cost (MSE):", mse_test)