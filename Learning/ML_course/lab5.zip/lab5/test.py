import numpy as np


np.random.seed(42)
#Generate random mat
X0 = np.zeros(30)
X1 = np.random.randint(0,10, 30)
X2 = np.random.randint(90,100, 30)
X3 = np.random.randint(90,800, 30)
y = np.random.randint(0,2, 30, dtype=int)
y.shape = 30,1

X = np.array([X0, X1, X2, X3]).T
print(X)
# X = np.hstack((np.ones((30, 1)), X))
print(X)
# Normalize features (except the bias column)

X[:, 1:] = (X[:, 1:] - np.mean(X[:, 1:], axis=0)) / np.std(X[:, 1:], axis=0)


def comp_gz(X, theta):
    gz = 1 / (1 + np.exp(-X @ theta))  # Sigmoid function
    return gz

def gradient_descent(X, y, iteration=100, alpha=0.01):
    m, n = X.shape  # Number of samples and features

    l_theta_history = []
    theta_history = []
    grad_logL_history = []

    # Initialize theta as a column vector
    theta = np.ones((n, 1))

    # Compute initial gz
    gz = comp_gz(X, theta)

    print(f"Dimension: gz {gz.shape}, X {X.shape}, y {y.shape}")

    # Compute log-likelihood
    def comp_log_likelihood(gz):
        log_theta = y.T @ np.log(gz) + (1 - y).T @ np.log(1 - gz)
        return log_theta.item()  # Return scalar value

    # Compute gradient of log-likelihood
    def gradient_logL(X, y, gz):
        grad_logL = X.T @ (y - gz)  # Matrix multiplication
        return grad_logL

    # Update theta
    def update_theta(theta, y, gz, X):
        theta_new = theta.copy()  # Create a copy of theta
        theta_new += alpha * (X.T @ (y - gz))  # Update theta
        return theta_new

    # Gradient descent loop
    for i in range(iteration):
        l_theta = comp_log_likelihood(gz)
        theta = update_theta(theta, y, gz, X)
        grad_logL = gradient_logL(X, y, gz)

        # Update gz with new theta
        gz = comp_gz(X, theta)

        # Save values
        l_theta_history.append(l_theta)
        theta_history.append(theta)
        grad_logL_history.append(grad_logL)

        # Print cost every 2 iterations
        if i % 5 == 0:
            print(f'Cost at iteration {i}:', l_theta)

    return np.array(l_theta_history), np.array(theta_history)


grad_logL_history, theta_history = gradient_descent(X, y, iteration= 100, alpha=1e-1)

print("Theta: ",theta_history[-1,:])